export class AuthModel {
	email: string;
	passwordHash: string;
}
