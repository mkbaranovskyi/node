export const ALREADY_REGISTERED_ERROR = 'Такой пользователь уже был зарегистрирован';
export const USER_NOT_FOUND_ERROR = 'Пользователь с таким email не найден';
export const WRONG_PASSWORD_ERROR = 'Неверный пароль';