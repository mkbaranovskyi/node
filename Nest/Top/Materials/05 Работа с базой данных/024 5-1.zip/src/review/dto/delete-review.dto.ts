export class DeleteReviewDto {
	_id: string;
}