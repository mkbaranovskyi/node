import { ReviewModel } from '../review.model';

export class SaveReviewDto extends ReviewModel {

}