export class ReviewModel {
	name: string;
	title: string;
	description: string;
	rating: number;
	createdAt: Date;
}
