export class DeleteTopPageDto {
	_id: string;
}