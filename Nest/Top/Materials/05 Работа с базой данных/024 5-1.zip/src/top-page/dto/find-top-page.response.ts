import { TopLevelCategory } from '../top-page.model';

export class FindTopPageResponse {
	firstCategory: TopLevelCategory;
	secondCategory: string;
	alias: string;
	title: string;
}