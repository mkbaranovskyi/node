import { TopPageModel } from '../top-page.model';

export class SaveTopPageModelDto extends TopPageModel {

}