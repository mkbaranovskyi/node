export class FindProductDto {
	category: string;
	limit: string;
}