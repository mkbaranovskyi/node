import { ProductModel } from '../product.model';

export class SaveProductDto extends ProductModel {

}