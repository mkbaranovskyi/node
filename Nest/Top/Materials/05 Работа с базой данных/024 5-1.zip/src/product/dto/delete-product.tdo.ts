export class DeleteProductDto {
	_id: string;
}