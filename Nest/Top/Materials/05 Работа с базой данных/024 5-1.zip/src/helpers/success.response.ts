export class SuccessResponse {
	succuss: boolean;
}