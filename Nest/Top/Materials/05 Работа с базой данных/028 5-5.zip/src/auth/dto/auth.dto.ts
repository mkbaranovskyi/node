export class AuthDto {
	login: string;
	password: string;
}